package com.bolao2022.bolao2022;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bolao2022ApplicationTests {

	@Test
	void contextLoads() {
	}

}
