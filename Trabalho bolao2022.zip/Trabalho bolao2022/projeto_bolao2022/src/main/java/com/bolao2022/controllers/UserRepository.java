package com.bolao2022.controllers;

import com.bolao2022.models.UserModel;
import com.bolao2022.models.UserModel;

class UserRepository {

    void save(UserModel user) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
