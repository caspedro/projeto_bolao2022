package com.bolao2022.project;


public class Time {
    private String nomeTecnico;
    private String nomeTime;
    
    
    public Time(){
    
    }
    
    public Time(String nomeTecnico, String nomeTime){
        this.nomeTecnico= nomeTecnico;
        this.nomeTime = nomeTime;
    }

    public String getNomeTecnico() {
        return nomeTecnico;
    }

    public void setNomeTecnico(String nomeTecnico) {
        this.nomeTecnico = nomeTecnico;
    }

    public String getNomeTime() {
        return nomeTime;
    }

    public void setNomeTime(String nomeTime) {
        this.nomeTime = nomeTime;
    }

    @Override
    public String toString() {
        return nomeTime + "\nTécnico: " + nomeTecnico;
    }
    
    
}
