package com.bolao2022.controllers;


import com.bolao2022.models.UserModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;



/*esse @Controller tem a função de ser uma camada intermediária entre a camada 
de apresentação (View) e a camada de negócios (Model). Deste modo, toda requisi-
ção criada pelo usuário deve passar pelo controller, e este então se comunica 
com o model.*/
@Controller
/*essa classe precisa ser pública, senão a aplicação nao seria encontrada*/
public class AuthController {
    
    /*criar uma variável booleana para ver se o usuario tem acesso ou nao. Ela 
    será chamada de isAuthenticated, mas poderia se chamar "vaca". */
   private Boolean isAuthenticated;
   
   /*esse @Autowired tem a função de fazer a conexao com o banco para salvar, e-
   ditar as informações do banco. em específico esse, é sobre os dados dos usuá-
   rios.*/
   @Autowired
   UserRepository userRepository;
   
   
   /*criarei um construtor chamado AuthController (tem que ser esse nome por 
   conta das regras do java, tem que ser igual ao nome da classe). nesse cons-
   trutor, pegarei a variavel que criei e igualarei ela a "false", para quando o
   usuario entrar no site, o proprio site travar ele na pagina de login, para o 
   user nao ter acesso às atividades do site antes de logar */
   public AuthController(){
       this.isAuthenticated = false;
   }
   
   
   /*esse @GetMapping é da própria linguagem do spring boot do java. o value = 
   "/" direciona o usuario para a pagina inicial*/
   @GetMapping (value = "/index.html")
   /*esse é um método criado para controlar o @GetMapping(value = "/")*/
   public String index(Model startpage){
       if (this.isAuthenticated){
           startpage.addAttribute("page", "dashboard");
           return "index.html";
       }else{
           return "login";
       }
   }
   
   /*criando a view de registro do usuario*/
   @GetMapping(value= "/register")
   public String register(UserModel register){
       return "register";
   }
   
   
   @GetMapping (value = "/adduser")
   public String registeruser(@Validated UserModel user, BindingResult result, Model model){
       if(result.hasErrors()){
            return "redirect:/register";
        }
        userRepository.save(user);
        return "redirect:/login";
   }
   
   @GetMapping(value = "/login")
    public String login(){
        if(this.isAuthenticated){
            return "index";
        }else{
            return "login";
        }
    }
    
    
    @GetMapping(value = "/forgot-password")
    public String forgotPassword(){
        if(this.isAuthenticated){
            return "index";
        }else{
            return "forgot-password";
        }
    }
    
}
