
package com.bolao2022.controllers;

import com.bolao2022.models.SelecaoModel;


class SelecaoRepository {

    Object findAll() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    void save(SelecaoModel selecao) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
