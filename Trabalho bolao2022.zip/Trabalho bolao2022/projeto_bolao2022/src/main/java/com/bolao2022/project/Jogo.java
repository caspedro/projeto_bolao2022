package com.bolao2022.project;


public class Jogo {
    private Time timeMandante;
    private Time timeVisitante;
    private int golsMandante;
    private int golsVisitante;

    // Construtor
    
    public Jogo(){
    
    }
    
    public Jogo(Time timeMandante, Time timeVisitante) {
        this.timeMandante = timeMandante;
        this.timeVisitante = timeVisitante;
       
    }

    public Jogo(Time timeMandante, Time timeVisitante, int golsMandante, int golsVisitante) {
        this.timeMandante = timeMandante;
        this.timeVisitante = timeVisitante;
        this.golsMandante = golsMandante;
        this.golsVisitante = golsVisitante;
    }

    // Métodos

    public Time Vencedor() {
        if (this.golsMandante > this.golsVisitante) {
            return this.timeMandante;
        } else if (this.golsVisitante > this.golsMandante) {
            return this.timeVisitante;
        } else {
            return null;
        }

    }
    
    public void golTimeMandante() {
        this.golsMandante += 1;
    }
    
    public void golTimeVisitante() {
        this.golsVisitante += 1;
    }


    public Time getTimeMandante() {
        return timeMandante;
    }

    public void setTimeMandante(Time timeMandante) {
        this.timeMandante = timeMandante;
    }

    public Time getTimeVisitante() {
        return timeVisitante;
    }

    public void setTimeVisitante(Time timeVisitante) {
        this.timeVisitante = timeVisitante;
    }
    
    public int getGolsMandante() {
        return golsMandante;
    }

    public void setGolsMandante(int golsMandante) {
        this.golsMandante = golsMandante;
    }

    public int getGolsVisitante() {
        return golsMandante;
    }

    public void setGolsVisitante(int golsVisitante) {
        this.golsVisitante = golsVisitante;
    }

    @Override
    public String toString() {
        return "Jogo{" + "timeMandante=" + timeMandante + ", timeVisitante=" + timeVisitante + ", golsMandante=" + golsMandante + ", golsVisitante=" + golsVisitante + '}';
    }

    
    
    
}
